package com.example.demo;

import com.example.demo.model.DoctorEntity;
import com.example.demo.repository.DoctorRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class Demo2Application {

    private static final Logger log = LoggerFactory.getLogger(Demo2Application.class);

    public static void main(String[] args) {
        SpringApplication.run(Demo2Application.class);
    }

    @Bean
    public CommandLineRunner demo(DoctorRepository repository) {
        return (args) -> {
          DoctorEntity doctor1 =  repository.retrieveByName("MBob");

//          //   save a few customers
//            repository.save(new DoctorEntity("Jack"));
//            repository.save(new DoctorEntity("Chloe"));
//            repository.save(new DoctorEntity("Kim"));
//            repository.save(new DoctorEntity("David"));
//            repository.save(new DoctorEntity("Miche"));

            // fetch all customers
            log.info("DoctorEntity found with findAll():");
            log.info("-------------------------------");
            for (DoctorEntity doctorEntity : repository.findAll()) {
                log.info(doctorEntity.getFirstName());
            }
            log.info("");

//            // fetch an individual customer by ID
//            DoctorEntity customer = repository.findById(1L);
//            log.info("Customer found with findById(1L):");
//            log.info("--------------------------------");
//            log.info(customer.toString());
//            log.info("");

            // fetch customers by first name
            log.info("Customer found with findByLastName('Bauer'):");

            log.info("--------------------------------------------");
             repository.findByFirstName("Bauer").forEach(bauer -> {
                log.info(bauer.toString());
               });
            // for (Customer bauer : repository.findByLastName("Bauer")) {
            //  log.info(bauer.toString());
            // }
            log.info("");
        };
    }

}