package com.example.demo.repository;

import com.example.demo.model.DoctorEntity;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

// This will be AUTO IMPLEMENTED by Spring into a Bean called userRepository
// CRUD refers Create, Read, Update, Delete

public interface DoctorRepository extends CrudRepository<DoctorEntity, Integer> {
    @Query("SELECT f FROM doctors f WHERE LOWER(f.firstName) = LOWER(:name)")
    DoctorEntity retrieveByName(@Param("name") String name);

    List<DoctorEntity> findByFirstName(String firstName);

   // DoctorEntity findById(long id);
}